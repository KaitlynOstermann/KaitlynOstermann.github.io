"use strict";
{
    document.querySelector("#d1").style.backgroundColor = "green";
}